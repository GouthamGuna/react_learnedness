console.log("Starting...")

function login() {

    let userName = document.getElementById('username').value;
    let password = document.getElementById('password').value;

    if (userName === '' || password === '') {
        alert('Please enter both username and password.');
        return;
    }

    if (userName === "admin" && password === "zk@AUTH24") {
        window.location.href = "player.html";
    } else {
        alert("Invalid credentials");
        window.location.href = "index.html";
    }

    // Clear form fields
    userName = '';
    password = '';
}