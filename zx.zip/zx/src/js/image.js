console.log("Starting...")

let currentPage = 1;
const recordsPerPage = 100;

function categorize() {
    // List of categories
    const categories = new Map();
    categories.set("Asian", "q_asian");
    categories.set("Big-Dick", "q_big-dick");
    categories.set("Hard Core", "q_hardcore");
    categories.set("Home Made", "q_homemade");
    categories.set("Japanese", "q_japanese");
    categories.set("Korean", "q_korean");
    categories.set("Latina", "q_latina");
    categories.set("Lesbians", "q_lesbians");
    categories.set("Mature", "q_mature");
    categories.set("Orgy", "q_orgy");
    categories.set("Red Head", "q_redhead");
    categories.set("Teen", "q_teen");

    //let temp;

    categories.forEach((k, v) => {
        let opt = document.createElement('option');
        opt.value = k;
        opt.innerText = v;
        document.getElementById('category').appendChild(opt);
        //temp = opt;
    });

    // Initial load
    displayImages(1, "q_asian");
}

async function fetchData(page, categorie) {
    alert(categorie)
    let response;
    if (categorie === undefined) {
        response = await fetch(`/database/q_asian.json`);
    } else {
        response = await fetch(`/database/${categorie}.json`);
    }
    let data = await response.json();
    return data.videos.slice((page - 1) * recordsPerPage, page * recordsPerPage);
}

async function displayImages(page, categorie) {
    alert("page : " + page + " category : " + categorie)
    let div = document.getElementById('image-container')
    div.innerHTML = '';

    let res = await fetchData(page, categorie);

    res.forEach(x => {
        x.thumbs.forEach(y => {
            let img = document.createElement("img");
            img.src = y.src;
            img.style.width = y.width;
            img.style.height = y.height;
            div.appendChild(img);
        })
    })
}

categorize();

// Function to load next page
function loadNextPage() {
    currentPage++;
    document.getElementById("nxt_count").innerHTML = currentPage;
    document.getElementById("prv_count").innerHTML = currentPage;
    displayData(currentPage);
}

// Function to load previous page
function loadPreviousPage() {
    if (currentPage > 1) {
        currentPage--;
        document.getElementById("prv_count").innerHTML = currentPage;
        document.getElementById("nxt_count").innerHTML = currentPage;
        displayData(currentPage);
    }
}

// Example usage: Load next page when a button is clicked
document.getElementById("nextPageButton").addEventListener("click", loadNextPage);

// Example usage: Load previous page when a button is clicked
document.getElementById("prevPageButton").addEventListener("click", loadPreviousPage);

console.log("Finished...");